using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

public class FastAssetSwap : EditorWindow
{
    public GameObject objectToSwapWith;

    [MenuItem("Tools/FAST Swap")]
    public static void CreateWindow()
    {
        GetWindow<FastAssetSwap>("FAST Swap");
    }

    void OnGUI()
    {
        objectToSwapWith = (GameObject)EditorGUILayout.ObjectField("Swap With", objectToSwapWith, typeof(GameObject), true);
        GUILayout.Label("Select All The Objects You Want To Swap");
        if(GUILayout.Button("Swap Selection"))
        {
            SwapSelection();
        }
    }

    void SwapSelection()
    {
        for (int i = 0; i < Selection.gameObjects.Length; i++)
        {
            GameObject createdObject = Instantiate(objectToSwapWith, Vector3.zero, Quaternion.identity);
            createdObject.transform.position = Selection.gameObjects[i].transform.localPosition;
            createdObject.transform.rotation = Selection.gameObjects[i].transform.rotation;
        }
    }
}
